
def hello(name: str):
    print(f'Hello {name}!')