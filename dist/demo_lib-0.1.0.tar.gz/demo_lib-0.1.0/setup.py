# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['demo_lib']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'demo-lib',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Joichiro433',
    'author_email': 'joichiro322@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
